from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent

def analyze(path,tag):
    d=np.load(path)
    U=d['far_u']; dt=float(d['sample_dt']); dx=float(d['dx']); omq=float(d['omega_qb'])
    A=U-U.mean(axis=0,keepdims=True)
    A=A*np.hanning(A.shape[0])[:,None]*np.hanning(A.shape[1])[None,:]
    nt=2*A.shape[0]; nx=2*A.shape[1]
    P=np.abs(np.fft.fft2(A,s=(nt,nx)))**2
    om=2*np.pi*np.fft.fftfreq(nt,d=dt)
    k=2*np.pi*np.fft.fftfreq(nx,d=dx)
    rows=[]
    for n in (3,5,7):
        target=n*omq
        k0=np.sqrt(target*target-1)
        ommask=(om>target-0.25)&(om<target+0.25)
        kmag=(np.abs(k)>k0-0.25)&(np.abs(k)<k0+0.25)
        outmask=k<0   # positive-omega FFT branch for right-going cos(kx-omega t)
        inmask=k>0
        Pout=float(P[np.ix_(ommask,kmag&outmask)].sum())
        Pin=float(P[np.ix_(ommask,kmag&inmask)].sum())
        frac=Pout/(Pout+Pin) if Pout+Pin>0 else np.nan
        rows.append({'tag':tag,'n':n,'omega_target':target,'k_target':k0,
                     'outgoing_power':Pout,'incoming_power':Pin,
                     'outgoing_fraction':frac,'out_in_ratio':Pout/Pin if Pin>0 else np.inf})
    return rows

def main():
    rows=[]
    for tag in ('spp320','late_spp160'):
        rows+=analyze(HERE/f'direct_radiation_data_{tag}.npz',tag)
    with open(HERE/'direct_radiation_komega_direction.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    print('K-OMEGA DIRECTIONALITY')
    for r in rows:
        print(f"{r['tag']:12s} n={r['n']} outgoing fraction={r['outgoing_fraction']:.6f} out/in={r['out_in_ratio']:.3e}")

if __name__=='__main__':
    main()
